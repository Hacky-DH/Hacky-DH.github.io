## GitHub Pages

GitHub Pages run [Jekyll](https://jekyllrb.com/) to build the pages.

See [Simple site](https://kbroman.org/simple_site/) and its [simple_site](https://github.com/kbroman/simple_site) github.
